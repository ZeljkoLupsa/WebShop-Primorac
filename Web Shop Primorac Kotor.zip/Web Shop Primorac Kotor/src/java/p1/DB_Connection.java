
package p1;

import java.sql.*;

public class DB_Connection 
{
    public static String SENDERS_EMAILID="zeljko.lupsa.fit@gmail.com";
    public static String SENDERS_PASSWORD="123456";
    
    public static Connection get_DBConnection()
    {
        Connection conn=null;
        try
        {
           Class.forName("com.mysql.jdbc.Driver");
           conn=DriverManager.getConnection("jdbc:mysql://localhost/idesign_db","root","abc");
           
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return conn;
    }
    
}
